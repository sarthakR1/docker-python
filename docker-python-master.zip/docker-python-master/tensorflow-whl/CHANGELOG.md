* `1.11.0-py36`: TensorFlow 1.11.0 wheels built with python 3.6
* `1.12.0-py36`: TensorFlow 1.12.0 wheels with Cuda 9.2
* `1.13.1-py36`: TensorFlow 1.13.1 wheels with Cuda 10.0
* `1.13.1-py36-2`: TensorFlow 1.13.1 wheels with Cuda 10.0 and bump anaconda3 base image version to 5.3.0 
* `1.13.1-py37`: TensorFlow 1.13.1 with Python 3.7.0 and bump anaconda3 base image version to 5.3.0 
* `1.13.1-py37-2`: TensorFlow 1.13.1 with Python 3.7.3
* `1.14.0-py36`: TensorFlow 1.14.0 with Python 3.6
* `2.0.0-rc1-py36`: TensorFlow 2.0.0 RC1 with Python 3.6
* `2.0.0-py36`: TensorFlow 2.0.0 with Python 3.6
* `2.1.0-rc0-py36`: TensorFlow 2.1.0-rc0 with Python 3.6
* `2.1.0-rc2-py36`: TensorFlow 2.1.0-rc2 with Python 3.6
* `2.1.0-py36`: TensorFlow 2.1.0 with Python 3.6
* `2.1.0-py36-2`: TensorFlow 2.1.0 with CUDA 10.1
* `2.1.0-py37`: TensorFlow 2.1.0 with Python 3.7
* `2.1.0-py37-2`: TensorFlow 2.1.0 with Python 3.7 & DLVM base image.
* `2.1.0-py37-3`: TensorFlow 2.1.0 with Python 3.7, DLVM base image, tensorflow-gcs-config.
* `2.2.0-py37`: TensorFlow 2.2.0 with Python 3.7.
* `2.2.0-py37-2`: TensorFlow 2.2.0 with Python 3.7 & TFA.
* `2.3.0-py37`: TensorFlow 2.3.0 with Python.