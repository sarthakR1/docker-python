import unittest

import kmapper as km

class TestKMapper(unittest.TestCase):
    def test_init(self):
        km.KeplerMapper()
