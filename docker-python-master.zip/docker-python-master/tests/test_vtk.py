import unittest


class TestVTK(unittest.TestCase):
    def test_import(self):
        import vtk
